cd vuepress
git init
git add -A
git commit -m 'deploy'
git push -f git@github.com:chenbeile/vuepress-blog.git master:gh-pages

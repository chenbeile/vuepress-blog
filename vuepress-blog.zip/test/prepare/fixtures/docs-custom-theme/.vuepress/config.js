module.exports = {
  title: 'Hello VuePress',
  description: 'Just playing around'
}
